const express = require("express");
const mysql = require("mysql2");

const app = express();


// Read JSON data
app.use(express.json());


// Serve HTML, CSS and JavaScript
app.use(express.static("public"));


// ===============================
// MySQL Connection
// ===============================

const db = mysql.createConnection({

    host: "localhost",

    user: "root",

    password: "kavya-19",

    database: "leave_management"

});


// ===============================
// Connect to MySQL
// ===============================

db.connect((err) => {

    if (err) {

        console.log("MySQL connection failed");

        console.log(err.message);

    }
    else {

        console.log("Connected to MySQL Database");

    }

});


// ===============================
// Home Page
// ===============================

app.get("/", (req, res) => {

    res.sendFile(
        __dirname + "/public/index.html"
    );

});


// ===============================
// Save Leave Request
// ===============================

app.post("/api/leave", (req, res) => {

    const employee_id =
        req.body.employee_id;

    const employee_name =
        req.body.employee_name;

    const designation =
        req.body.designation;

    const from_date =
        req.body.from_date;

    const to_date =
        req.body.to_date;

    const no_of_days =
        req.body.no_of_days;

    const type_of_leave =
        req.body.type_of_leave;

    const description =
        req.body.description;


    // Check all fields

    if (
        !employee_id ||
        !employee_name ||
        !designation ||
        !from_date ||
        !to_date ||
        !no_of_days ||
        !type_of_leave ||
        !description
    ) {

        return res.status(400).json({

            success: false,

            message: "Please fill all the fields."

        });

    }


    // Check number of days

    if (
        Number(no_of_days) < 1 ||
        Number(no_of_days) > 30
    ) {

        return res.status(400).json({

            success: false,

            message:
                "Leave days must be between 1 and 30."

        });

    }


    // Check date order

    if (to_date < from_date) {

        return res.status(400).json({

            success: false,

            message:
                "To Date cannot be before From Date."

        });

    }


    // SQL query

    const sql = `

        INSERT INTO leave_requests

        (
            employee_id,
            employee_name,
            designation,
            from_date,
            to_date,
            no_of_days,
            type_of_leave,
            description
        )

        VALUES (?, ?, ?, ?, ?, ?, ?, ?)

    `;


    db.query(

        sql,

        [

            employee_id,
            employee_name,
            designation,
            from_date,
            to_date,
            no_of_days,
            type_of_leave,
            description

        ],

        (err, result) => {

            if (err) {

                console.log(err);

                return res.status(500).json({

                    success: false,

                    message:
                        "Error saving leave request."

                });

            }


            res.json({

                success: true,

                message:
                    "Leave request submitted successfully.",

                id: result.insertId

            });

        }

    );

});


// ===============================
// View All Leave Requests
// ===============================

app.get("/api/leaves", (req, res) => {

    const sql = `

        SELECT *

        FROM leave_requests

        ORDER BY id DESC

    `;


    db.query(sql, (err, result) => {

        if (err) {

            console.log(err);

            return res.status(500).json({

                success: false,

                message:
                    "Error retrieving leave requests."

            });

        }


        res.json(result);

    });

});


// ===============================
// Start Server
// ===============================

// ==========================================
// LEAVE STATISTICS
// ==========================================

app.get("/api/leave-stats", (req, res) => {

    const sql = `

        SELECT

            (
                SELECT COUNT(DISTINCT employee_id)
                FROM leave_requests
                WHERE status = 'Pending'
            ) AS pending_people,

            (
                SELECT COUNT(*)
                FROM leave_requests
            ) AS total_requests

    `;


    db.query(sql, (err, result) => {

        if (err) {

            console.log(err);

            return res.status(500).json({

                success: false,

                message: "Could not fetch leave statistics."

            });

        }


        res.json({

            success: true,

            pending_people:
                result[0].pending_people,

            total_requests:
                result[0].total_requests

        });

    });

});

app.listen(3000, () => {

    console.log(
        "Server running at http://localhost:3000"
    );

});