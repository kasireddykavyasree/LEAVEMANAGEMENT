
// ==========================================
// FIRST PAGE - LIVE LEAVE STATISTICS
// ==========================================

async function loadLeaveStats() {

    const pendingPeople =
        document.getElementById("pendingPeople");

    const totalRequests =
        document.getElementById("totalRequests");


    if (!pendingPeople || !totalRequests) {
        return;
    }


    try {

        const response =
            await fetch("/api/leave-stats");


        const data =
            await response.json();


        if (data.success) {

            pendingPeople.textContent =
                data.pending_people;

            totalRequests.textContent =
                data.total_requests;

        }

    }
    catch (error) {

        console.log(
            "Could not load leave statistics."
        );

    }

}


// Load when page opens
loadLeaveStats();


// Refresh every 30 seconds
setInterval(
    loadLeaveStats,
    30000
);

// ==========================================
// PAGE 1
// EMPLOYEE DETAILS
// ==========================================

const employeeForm =
    document.getElementById("employeeForm");


if (employeeForm) {


    employeeForm.addEventListener(
        "submit",
        function(event) {

            event.preventDefault();


            const employee_id =
                document.getElementById(
                    "employee_id"
                ).value.trim();


            const employee_name =
                document.getElementById(
                    "employee_name"
                ).value.trim();


            const designation =
                document.getElementById(
                    "designation"
                ).value.trim();


            const employeeData = {

                employee_id:
                    employee_id,

                employee_name:
                    employee_name,

                designation:
                    designation

            };


            // Store temporarily

            sessionStorage.setItem(

                "employeeData",

                JSON.stringify(employeeData)

            );


            // Move to page 2

            window.location.href =
                "leave.html";

        }
    );

}


// ==========================================
// PAGE 2
// LEAVE DETAILS
// ==========================================

const leaveForm =
    document.getElementById("leaveForm");


if (leaveForm) {


    // Get employee data

    const employeeData =
        JSON.parse(

            sessionStorage.getItem(
                "employeeData"
            )

        );


    // If no employee data
    // return to first page

    if (!employeeData) {

        window.location.href =
            "index.html";

    }


    // ======================================
    // SHOW EMPLOYEE INFORMATION
    // ======================================

    document.getElementById(
        "employeeSummary"
    ).innerHTML = `

        <div>

            <small>
                Employee ID
            </small>

            <strong>
                ${employeeData.employee_id}
            </strong>

        </div>


        <div>

            <small>
                Employee Name
            </small>

            <strong>
                ${employeeData.employee_name}
            </strong>

        </div>


        <div>

            <small>
                Designation
            </small>

            <strong>
                ${employeeData.designation}
            </strong>

        </div>

    `;


    // ======================================
    // DATE ELEMENTS
    // ======================================

    const fromDate =
        document.getElementById(
            "from_date"
        );


    const toDate =
        document.getElementById(
            "to_date"
        );


    const daysNumber =
        document.getElementById(
            "daysNumber"
        );


    const daysText =
        document.getElementById(
            "daysText"
        );


    // Set minimum date = today

    const today =
        new Date()
            .toISOString()
            .split("T")[0];


    fromDate.min = today;

    toDate.min = today;


    // ======================================
    // CALCULATE DAYS
    // ======================================

    function calculateDays() {


        if (
            !fromDate.value ||
            !toDate.value
        ) {

            daysNumber.value = 0;

            daysText.textContent =
                "Select both dates to calculate the number of days.";

            return 0;

        }


        const start =
            new Date(
                fromDate.value + "T00:00:00Z"
            );


        const end =
            new Date(
                toDate.value + "T00:00:00Z"
            );


        // Invalid date order

        if (end < start) {

            daysNumber.value = 0;

            daysText.textContent =
                "To Date cannot be before From Date.";

            daysText.style.color =
                "#c0392b";

            return 0;

        }


        const difference =
            end - start;


        const days =
            Math.floor(
                difference /
                (1000 * 60 * 60 * 24)
            ) + 1;


        // Maximum 30 days

        if (days > 30) {

            daysNumber.value = 0;

            daysText.textContent =
                "Leave cannot be more than 30 days.";

            daysText.style.color =
                "#c0392b";

            return 0;

        }


        daysNumber.value =
            days;


        daysText.style.color =
            "#1f4e79";


        if (days === 1) {

            daysText.textContent =
                "1 day selected.";

        }
        else {

            daysText.textContent =
                days + " days selected.";

        }


        return days;

    }


    // Run whenever dates change

    fromDate.addEventListener(
        "change",
        function() {

            // To date cannot be earlier than from date

            toDate.min =
                fromDate.value;

            calculateDays();

        }
    );


    toDate.addEventListener(
        "change",
        function() {

            calculateDays();

        }
    );


    // ======================================
    // BACK BUTTON
    // ======================================

    document.getElementById(
        "backBtn"
    ).addEventListener(
        "click",
        function() {

            window.location.href =
                "index.html";

        }
    );


    // ======================================
    // SUBMIT FORM
    // ======================================

    leaveForm.addEventListener(
        "submit",
        async function(event) {


            event.preventDefault();


            const errorMessage =
                document.getElementById(
                    "errorMessage"
                );


            errorMessage.textContent =
                "";


            // Calculate again

            const days =
                calculateDays();


            // Stop if date problem

            if (days < 1) {

                errorMessage.textContent =
                    "Please select valid leave dates.";

                return;

            }


            const type_of_leave =
                document.getElementById(
                    "type_of_leave"
                ).value;


            const description =
                document.getElementById(
                    "description"
                ).value.trim();


            if (!type_of_leave) {

                errorMessage.textContent =
                    "Please select the type of leave.";

                return;

            }


            if (!description) {

                errorMessage.textContent =
                    "Please enter the description.";

                return;

            }


            // ==================================
            // FINAL DATA
            // ==================================

            const leaveData = {

                employee_id:
                    employeeData.employee_id,

                employee_name:
                    employeeData.employee_name,

                designation:
                    employeeData.designation,

                from_date:
                    fromDate.value,

                to_date:
                    toDate.value,

                no_of_days:
                    days,

                type_of_leave:
                    type_of_leave,

                description:
                    description

            };


            try {


                // Send to app.js

                const response =
                    await fetch(
                        "/api/leave",
                        {

                            method: "POST",

                            headers: {

                                "Content-Type":
                                    "application/json"

                            },

                            body:
                                JSON.stringify(
                                    leaveData
                                )

                        }
                    );


                const result =
                    await response.json();


                if (!response.ok) {

                    errorMessage.textContent =
                        result.message;

                    return;

                }


                // Store for success page

                sessionStorage.setItem(

                    "submittedLeave",

                    JSON.stringify(leaveData)

                );


                sessionStorage.setItem(

                    "leaveId",

                    result.id

                );


                // Go to success page

                window.location.href =
                    "success.html";


            }
            catch(error) {


                console.log(error);


                errorMessage.textContent =
                    "Server connection failed. Make sure app.js is running.";

            }

        }
    );

}


// ==========================================
// SUCCESS PAGE
// ==========================================

const successDetails =
    document.getElementById(
        "successDetails"
    );


if (successDetails) {


    const leaveData =
        JSON.parse(

            sessionStorage.getItem(
                "submittedLeave"
            )

        );


    const leaveId =
        sessionStorage.getItem(
            "leaveId"
        );


    if (leaveData) {


        successDetails.innerHTML = `

            <div>

                <span>
                    Request ID
                </span>

                <strong>
                    ${leaveId}
                </strong>

            </div>


            <div>

                <span>
                    Employee ID
                </span>

                <strong>
                    ${leaveData.employee_id}
                </strong>

            </div>


            <div>

                <span>
                    Employee Name
                </span>

                <strong>
                    ${leaveData.employee_name}
                </strong>

            </div>


            <div>

                <span>
                    Designation
                </span>

                <strong>
                    ${leaveData.designation}
                </strong>

            </div>


            <div>

                <span>
                    From Date
                </span>

                <strong>
                    ${leaveData.from_date}
                </strong>

            </div>


            <div>

                <span>
                    To Date
                </span>

                <strong>
                    ${leaveData.to_date}
                </strong>

            </div>


            <div>

                <span>
                    No. of Days
                </span>

                <strong>
                    ${leaveData.no_of_days}
                </strong>

            </div>


            <div>

                <span>
                    Type of Leave
                </span>

                <strong>
                    ${leaveData.type_of_leave}
                </strong>

            </div>


            <div>

                <span>
                    Description
                </span>

                <strong>
                    ${leaveData.description}
                </strong>

            </div>

        `;

    }


    // View saved data

    document.getElementById(
        "viewDataBtn"
    ).addEventListener(
        "click",
        function() {

            window.open(
                "/api/leaves",
                "_blank"
            );

        }
    );

}